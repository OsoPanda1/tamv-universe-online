import React, { useState, useEffect } from 'react';
import TamvWorld from './components/World/TamvWorld';
import Loader from './components/UI/Loader';
import { initializeGemini } from './services/geminiService';
import { AppState, UserProfile } from './types';
import { Key, UserPlus, ArrowRight } from 'lucide-react';

declare global {
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }
  interface Window {
    aistudio?: AIStudio;
  }
}

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.LOADING);
  const [apiKey, setApiKey] = useState<string | null>(process.env.API_KEY || null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [regName, setRegName] = useState('');

  useEffect(() => {
    const init = async () => {
      let currentKey = process.env.API_KEY;

      if (!currentKey && window.aistudio) {
        try {
          const hasKey = await window.aistudio.hasSelectedApiKey();
          if (!hasKey) {
            setAppState(AppState.API_KEY_SELECT);
            return;
          }
        } catch (e) {
            console.error("AI Studio Check Error", e);
        }
      }

      if (currentKey) {
        initializeGemini(currentKey);
        setApiKey(currentKey);
      } else {
         setAppState(AppState.API_KEY_SELECT);
      }
    };

    init();
  }, []);

  const handleLoaderComplete = () => {
    // Check if user is registered (simulated local check)
    if (!userProfile) {
        setAppState(AppState.REGISTRATION);
    } else {
        setAppState(AppState.TUTORIAL);
    }
  };

  const handleRegistration = (e: React.FormEvent) => {
      e.preventDefault();
      if (!regName.trim()) return;
      
      // Create mock profile
      const newProfile: UserProfile = {
          id: 'user-' + Date.now(),
          username: regName,
          reputation: 100,
          wallet: { msr: 50, tamv: 10 }
      };
      setUserProfile(newProfile);
      setAppState(AppState.TUTORIAL);
  };

  const handleTutorialComplete = () => {
    setAppState(AppState.HUB);
  }

  const handleSelectKey = async () => {
    if (window.aistudio) {
      try {
        await window.aistudio.openSelectKey();
        setAppState(AppState.LOADING);
        window.location.reload(); 
      } catch (e) {
        alert("Failed to select key.");
      }
    }
  };

  if (appState === AppState.LOADING) {
    return <Loader onComplete={handleLoaderComplete} />;
  }

  if (appState === AppState.REGISTRATION) {
      return (
        <div className="fixed inset-0 bg-black flex items-center justify-center p-4 font-rajdhani overflow-hidden">
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1534972195531-d756b9bfa9f2?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center opacity-20"></div>
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black"></div>
            
            <div className="relative z-10 w-full max-w-md bg-black/60 backdrop-blur-xl border border-white/10 p-8 rounded-2xl shadow-[0_0_50px_rgba(34,211,238,0.2)]">
                <div className="flex flex-col items-center mb-8">
                    <div className="w-20 h-20 bg-cyan-500/10 rounded-full flex items-center justify-center border border-cyan-500/50 mb-4 animate-pulse">
                        <UserPlus className="w-8 h-8 text-cyan-400" />
                    </div>
                    <h2 className="text-3xl font-bold text-white font-orbitron tracking-widest text-center">CITIZEN REGISTRY</h2>
                    <p className="text-cyan-400/60 text-sm uppercase tracking-[0.2em]">KAOS System Integration</p>
                </div>

                <form onSubmit={handleRegistration} className="space-y-6">
                    <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Avatar Callsign</label>
                        <input 
                            type="text" 
                            value={regName}
                            onChange={(e) => setRegName(e.target.value)}
                            className="w-full bg-black/50 border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyan-500 transition-colors text-lg font-mono"
                            placeholder="Enter Username..."
                            autoFocus
                        />
                    </div>
                    
                    <button 
                        type="submit"
                        className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-4 rounded-xl transition-all shadow-[0_0_20px_rgba(34,211,238,0.4)] flex items-center justify-center gap-2 uppercase tracking-widest group"
                    >
                        <span>Initialize ID</span>
                        <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </button>
                </form>
            </div>
        </div>
      );
  }

  if (appState === AppState.API_KEY_SELECT) {
    return (
      <div className="fixed inset-0 bg-black flex items-center justify-center p-4 font-rajdhani">
        <div className="max-w-md w-full bg-zinc-900 border border-zinc-800 p-8 rounded-2xl shadow-2xl text-center relative">
            <Key className="text-cyan-400 w-8 h-8 mx-auto mb-6" />
            <h1 className="text-3xl font-bold text-white mb-2 font-orbitron">ACCESS RESTRICTED</h1>
            <p className="text-gray-400 mb-8">A valid neural link (API Key) is required.</p>
            <button 
                onClick={handleSelectKey}
                className="w-full py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold rounded-xl uppercase tracking-wider font-orbitron"
            >
                Initialize Neural Link
            </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full">
      {apiKey && userProfile && (
        <TamvWorld 
            apiKey={apiKey} 
            showTutorial={appState === AppState.TUTORIAL}
            onTutorialComplete={handleTutorialComplete}
            userProfile={userProfile}
        />
      )}
    </div>
  );
};

export default App;