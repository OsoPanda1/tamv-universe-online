import React, { useState } from 'react';
import { 
  Home, 
  ShoppingBag, 
  Map as MapIcon, 
  Radio, 
  User, 
  Settings, 
  ChevronUp, 
  Camera, 
  Music,
  Video,
  Globe
} from 'lucide-react';

interface CrystalDockProps {
  onNavigate: (zoneId: string) => void;
  activeZone: string | null;
}

const CrystalDock: React.FC<CrystalDockProps> = ({ onNavigate, activeZone }) => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [expandedMenu, setExpandedMenu] = useState<string | null>(null);

  const mainItems = [
    { id: 'hub', icon: Home, label: 'Hub', type: 'link' },
    { id: 'media', icon: Camera, label: 'Media', type: 'accordion', subItems: [
        { id: 'photos', icon: Camera, label: 'Photos' },
        { id: 'videos', icon: Video, label: 'Videos' },
        { id: 'music', icon: Music, label: 'Music' }
    ]},
    { id: 'market', icon: ShoppingBag, label: 'Market', type: 'link' },
    { id: 'stream', icon: Radio, label: 'Live', type: 'link' },
    { id: 'profile', icon: User, label: 'ID', type: 'link' },
  ];

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center">
      
      {/* Expanded Accordion Area (Retractable) */}
      <div className={`
        mb-4 flex gap-2 transition-all duration-500 ease-out overflow-hidden
        ${expandedMenu ? 'opacity-100 max-h-20 translate-y-0' : 'opacity-0 max-h-0 translate-y-4 pointer-events-none'}
      `}>
         {expandedMenu && mainItems.find(i => i.id === expandedMenu)?.subItems?.map((sub) => (
             <button
                key={sub.id}
                onClick={() => {
                    onNavigate(sub.id);
                    setExpandedMenu(null);
                }}
                className="group relative flex items-center gap-2 bg-black/40 backdrop-blur-xl border border-cyan-500/30 px-4 py-2 rounded-full text-cyan-100 hover:bg-cyan-500/20 hover:border-cyan-400 transition-all shadow-[0_0_15px_rgba(0,0,0,0.3)]"
             >
                <sub.icon className="w-4 h-4" />
                <span className="text-xs font-bold font-orbitron">{sub.label}</span>
                <div className="absolute inset-0 rounded-full bg-cyan-400/10 blur-md opacity-0 group-hover:opacity-100 transition-opacity"></div>
             </button>
         ))}
      </div>

      {/* Main Dock */}
      <div 
        className="flex items-center gap-2 px-4 py-3 bg-white/5 backdrop-blur-2xl border border-white/10 rounded-full shadow-[0_10px_40px_rgba(0,0,0,0.5)] transition-all duration-300 hover:border-white/30 hover:shadow-[0_0_30px_rgba(34,211,238,0.15)]"
      >
        {mainItems.map((item, index) => {
          const isActive = activeZone === item.id;
          const isHovered = hoveredIndex === index;
          const Icon = item.icon;

          return (
            <div key={item.id} className="relative group">
              <button
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
                onClick={() => {
                    if (item.type === 'accordion') {
                        setExpandedMenu(expandedMenu === item.id ? null : item.id);
                    } else {
                        onNavigate(item.id);
                        setExpandedMenu(null);
                    }
                }}
                className={`
                  relative flex items-center justify-center rounded-2xl transition-all duration-300 ease-out
                  ${isHovered ? 'w-14 h-14 -translate-y-2' : 'w-12 h-12'}
                  ${isActive ? 'bg-cyan-500/20 border-cyan-500/50' : 'bg-transparent border-transparent'}
                  border hover:bg-white/10 hover:border-white/30
                `}
              >
                <Icon 
                    className={`
                        transition-all duration-300
                        ${isHovered ? 'w-6 h-6 text-white' : 'w-5 h-5 text-gray-400'}
                        ${isActive ? 'text-cyan-400' : ''}
                    `} 
                />
                
                {/* Glow Effect on Hover */}
                {isHovered && (
                    <div className="absolute inset-0 rounded-2xl bg-cyan-400/20 blur-xl"></div>
                )}
                
                {/* Active Indicator */}
                {isActive && (
                    <div className="absolute -bottom-1 w-1 h-1 bg-cyan-400 rounded-full shadow-[0_0_5px_rgba(34,211,238,1)]"></div>
                )}
              </button>
              
              {/* Tooltip */}
              <div className={`
                absolute -top-10 left-1/2 -translate-x-1/2 px-2 py-1 bg-black/80 text-white text-[10px] font-bold uppercase tracking-widest rounded border border-white/10 backdrop-blur-sm pointer-events-none transition-all duration-200
                ${isHovered ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}
              `}>
                {item.label}
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Decorative Bottom Line */}
      <div className="w-32 h-1 mt-4 bg-gradient-to-r from-transparent via-cyan-500/20 to-transparent rounded-full blur-sm"></div>
    </div>
  );
};

export default CrystalDock;