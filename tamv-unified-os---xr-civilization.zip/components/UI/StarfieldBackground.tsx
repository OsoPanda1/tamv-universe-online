import React, { useEffect, useRef } from 'react';

const StarfieldBackground = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let stars: { x: number; y: number; z: number; o: number }[] = [];
    
    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const initStars = () => {
      stars = [];
      const numStars = 800;
      for (let i = 0; i < numStars; i++) {
        stars.push({
          x: Math.random() * canvas.width - canvas.width / 2,
          y: Math.random() * canvas.height - canvas.height / 2,
          z: Math.random() * canvas.width,
          o: Math.random()
        });
      }
    };

    const update = () => {
      const cx = canvas.width / 2;
      const cy = canvas.height / 2;
      const speed = 2; // Speed of travel

      ctx.fillStyle = "#000000";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      for (let i = 0; i < stars.length; i++) {
        const star = stars[i];
        star.z -= speed;

        if (star.z <= 0) {
          star.x = Math.random() * canvas.width - canvas.width / 2;
          star.y = Math.random() * canvas.height - canvas.height / 2;
          star.z = canvas.width;
          star.o = Math.random();
        }

        const x = cx + (star.x / star.z) * canvas.width;
        const y = cy + (star.y / star.z) * canvas.width;
        const size = (1 - star.z / canvas.width) * 2.5;
        const alpha = (1 - star.z / canvas.width);

        if (x >= 0 && x < canvas.width && y >= 0 && y < canvas.height) {
          // Color logic based on "depth" or random for aesthetic
          const color = star.o > 0.8 ? '#a855f7' : (star.o > 0.6 ? '#4ade80' : '#22d3ee');
          
          ctx.beginPath();
          ctx.fillStyle = color;
          ctx.globalAlpha = alpha;
          ctx.arc(x, y, size, 0, 2 * Math.PI);
          ctx.fill();
        }
      }
      animationFrameId = requestAnimationFrame(update);
    };

    resize();
    initStars();
    update();

    window.addEventListener('resize', resize);

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 z-0 pointer-events-none bg-black"
    />
  );
};

export default StarfieldBackground;