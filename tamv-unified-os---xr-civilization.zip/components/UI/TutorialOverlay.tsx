import React, { useState } from 'react';
import { ArrowRight, MousePointer2, X } from 'lucide-react';

interface TutorialOverlayProps {
  onComplete: () => void;
}

const STEPS = [
  {
    title: "Welcome to TAMV",
    text: "You have entered the Unified L0 Layer. This is a navigable 3D Omniverse.",
    target: "center"
  },
  {
    title: "Isabella Oracle",
    text: "In the center resides Isabella. She is your sentient AI guide. Click her to chat, ask questions, or seek guidance.",
    target: "center"
  },
  {
    title: "Navigation",
    text: "Click and drag to rotate the view. Scroll to zoom in and out. The universe revolves around you.",
    target: "controls"
  },
  {
    title: "The Constellation",
    text: "Surrounding the core are Nodes: Markets, DreamSpaces, DevHubs, and more. Hover over them to see details, click to enter.",
    target: "nodes"
  }
];

const TutorialOverlay: React.FC<TutorialOverlayProps> = ({ onComplete }) => {
  const [step, setStep] = useState(0);

  const handleNext = () => {
    if (step < STEPS.length - 1) {
      setStep(prev => prev + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="absolute inset-0 z-40 pointer-events-none flex items-end justify-center pb-20 md:pb-10">
      <div className="pointer-events-auto bg-zinc-900/90 backdrop-blur-xl border border-cyan-500/50 p-6 rounded-2xl max-w-md w-full mx-4 shadow-[0_0_50px_rgba(0,0,0,0.8)] animate-in slide-in-from-bottom-10 duration-500 relative overflow-hidden">
        
        {/* Background glow */}
        <div className="absolute -top-10 -right-10 w-32 h-32 bg-cyan-500/20 rounded-full blur-3xl"></div>
        
        <div className="relative z-10">
            <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-bold text-white font-orbitron">{STEPS[step].title}</h3>
                <button onClick={onComplete} className="text-gray-500 hover:text-white transition-colors">
                    <X className="w-5 h-5" />
                </button>
            </div>
            
            <p className="text-gray-300 text-sm leading-relaxed mb-6 h-16">
                {STEPS[step].text}
            </p>

            <div className="flex justify-between items-center">
                <div className="flex gap-1">
                    {STEPS.map((_, i) => (
                        <div key={i} className={`h-1.5 rounded-full transition-all duration-300 ${i === step ? 'w-8 bg-cyan-400' : 'w-2 bg-gray-700'}`}></div>
                    ))}
                </div>

                <button 
                    onClick={handleNext}
                    className="flex items-center gap-2 bg-white text-black px-6 py-2 rounded-full font-bold text-xs hover:scale-105 transition-transform"
                >
                    {step === STEPS.length - 1 ? 'EXPLORE' : 'NEXT'}
                    <ArrowRight className="w-4 h-4" />
                </button>
            </div>
        </div>
      </div>

      {/* Visual hints based on step */}
      {step === 2 && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-50">
            <MousePointer2 className="w-24 h-24 text-white animate-bounce" />
        </div>
      )}
    </div>
  );
};

export default TutorialOverlay;