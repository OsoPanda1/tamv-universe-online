import React, { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html, Float, MeshTransmissionMaterial } from '@react-three/drei';
import * as THREE from 'three';
import { ZoneData } from '../../types';

interface IridescentNodeProps {
  data: ZoneData;
  onInteract: (id: string) => void;
}

const IridescentNode: React.FC<IridescentNodeProps> = ({ data, onInteract }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  // Pulse animation
  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    
    if (meshRef.current) {
      meshRef.current.rotation.x = Math.sin(t * 0.2) * 0.2;
      meshRef.current.rotation.y += 0.005;
      
      const scale = hovered 
        ? 1 + Math.sin(t * 10) * 0.05 
        : 1 + Math.sin(t * 2) * 0.02;
        
      const baseScale = data.scale || 1;
      meshRef.current.scale.lerp(new THREE.Vector3(scale * baseScale, scale * baseScale, scale * baseScale), 0.1);
    }
  });

  return (
    <group position={new THREE.Vector3(...data.position)}>
      <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
        
        {/* Interactive Crystal Mesh */}
        <mesh 
          ref={meshRef}
          onPointerOver={() => { setHovered(true); document.body.style.cursor = 'pointer'; }}
          onPointerOut={() => { setHovered(false); document.body.style.cursor = 'auto'; }}
          onClick={() => onInteract(data.id)}
        >
          {/* Icosahedron for more crystal-like structure than sphere */}
          <icosahedronGeometry args={[0.7, 1]} /> 
          
          {/* High-Quality Transmission Material (Glass-like) */}
          <MeshTransmissionMaterial 
            backside
            samples={4}
            thickness={2}
            chromaticAberration={0.5}
            anisotropy={0.3}
            distortion={0.5}
            distortionScale={0.3}
            temporalDistortion={0.5}
            iridescence={1}
            iridescenceIOR={1.3}
            iridescenceThicknessRange={[0, 400]}
            color={hovered ? "#ffffff" : data.color}
            emissive={data.color}
            emissiveIntensity={hovered ? 0.5 : 0.1}
            toneMapped={true}
          />
        </mesh>

        {/* Core Light */}
        <pointLight color={data.color} intensity={1} distance={3} decay={2} />

        {/* Label UI */}
        <Html position={[0, -1.2, 0]} center distanceFactor={12} style={{pointerEvents:'none'}}>
          <div className={`transition-all duration-500 ${hovered ? 'opacity-100 translate-y-0 scale-110' : 'opacity-60 translate-y-2 scale-100'}`}>
            <div className="flex flex-col items-center">
                <div className="bg-black/40 backdrop-blur-xl border border-white/10 px-4 py-2 rounded-full flex items-center gap-2 shadow-[0_0_20px_rgba(255,255,255,0.1)]">
                    <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{backgroundColor: data.color, boxShadow: `0 0 10px ${data.color}`}}></div>
                    <span className="text-white text-xs font-bold tracking-widest whitespace-nowrap font-orbitron">{data.name}</span>
                </div>
            </div>
          </div>
        </Html>

      </Float>
      
      {/* Visual Anchor */}
      <mesh position={[0, -5, 0]}>
        <cylinderGeometry args={[0.01, 0.01, 10, 4]} />
        <meshBasicMaterial color={data.color} transparent opacity={0.15} blending={THREE.AdditiveBlending} />
      </mesh>
    </group>
  );
};

export default IridescentNode;