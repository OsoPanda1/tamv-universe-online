import React, { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Image, Text } from '@react-three/drei';
import * as THREE from 'three';
import { MediaItem } from '../../types';

interface MediaCarouselProps {
  items: MediaItem[];
  radius?: number;
}

const MediaCarousel: React.FC<MediaCarouselProps> = ({ items, radius = 5 }) => {
  const groupRef = useRef<THREE.Group>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const targetRotation = useRef(0);

  useFrame((state, delta) => {
    if (groupRef.current) {
      // Smooth rotation to target
      groupRef.current.rotation.y = THREE.MathUtils.lerp(
        groupRef.current.rotation.y,
        targetRotation.current,
        delta * 3
      );
    }
  });

  const handleNext = () => {
    setActiveIndex((prev) => (prev + 1) % items.length);
    targetRotation.current -= (Math.PI * 2) / items.length;
  };

  const handlePrev = () => {
      setActiveIndex((prev) => (prev - 1 + items.length) % items.length);
      targetRotation.current += (Math.PI * 2) / items.length;
  };

  return (
    <group position={[0, 2, 0]}>
        
      {/* Navigation Buttons (Floating 3D Text/Shapes) */}
      <group position={[-radius - 2, 0, 0]} onClick={handlePrev} onPointerOver={() => document.body.style.cursor='pointer'} onPointerOut={() => document.body.style.cursor='auto'}>
          <Text fontSize={2} color="#22d3ee" font="https://fonts.gstatic.com/s/orbitron/v19/yMJMMIlzdpvBhQQL_SC3X9yhF25-T1nygyU.woff">
              {"<"}
          </Text>
      </group>
      <group position={[radius + 2, 0, 0]} onClick={handleNext} onPointerOver={() => document.body.style.cursor='pointer'} onPointerOut={() => document.body.style.cursor='auto'}>
          <Text fontSize={2} color="#22d3ee" font="https://fonts.gstatic.com/s/orbitron/v19/yMJMMIlzdpvBhQQL_SC3X9yhF25-T1nygyU.woff">
              {">"}
          </Text>
      </group>

      <group ref={groupRef}>
        {items.map((item, i) => {
          const angle = (i / items.length) * Math.PI * 2;
          const x = Math.sin(angle) * radius;
          const z = Math.cos(angle) * radius;
          
          return (
            <group 
                key={item.id} 
                position={[x, 0, z]} 
                rotation={[0, angle, 0]}
            >
              <mesh position={[0, 0, 0]}>
                <planeGeometry args={[3, 2]} />
                <meshBasicMaterial color="#000" side={THREE.DoubleSide} />
                <Image url={item.url} scale={[3, 2, 1]} opacity={1} transparent />
              </mesh>
              
              {/* Frame/Glow */}
              <mesh position={[0, 0, -0.05]}>
                  <planeGeometry args={[3.1, 2.1]} />
                  <meshBasicMaterial color="#22d3ee" transparent opacity={0.3} />
              </mesh>

              <Text 
                position={[0, -1.3, 0]} 
                fontSize={0.2} 
                color="white"
                anchorX="center"
                anchorY="middle"
                font="https://fonts.gstatic.com/s/rajdhani/v10/L1x4T5M6Vw8N7M0Xp9h.woff"
              >
                {item.title}
              </Text>
            </group>
          );
        })}
      </group>

      {/* Floor reflection simulation */}
      <mesh rotation={[-Math.PI/2, 0, 0]} position={[0, -2, 0]}>
          <circleGeometry args={[radius + 2, 32]} />
          <meshBasicMaterial color="#000" opacity={0.5} transparent />
      </mesh>
    </group>
  );
};

export default MediaCarousel;