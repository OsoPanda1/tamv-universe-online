import React, { useRef, useState, useMemo, useEffect } from 'react';
import { Canvas, useFrame, useThree, useLoader } from '@react-three/fiber';
import { OrbitControls, Stars, Environment, Float, Cloud } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette, Noise, ChromaticAberration } from '@react-three/postprocessing';
import * as THREE from 'three';
import IsabellaOracle from './IsabellaOracle';
import IridescentNode from './IridescentNode';
import MediaCarousel from './MediaCarousel';
import MarketInterface from '../UI/MarketInterface';
import TutorialOverlay from '../UI/TutorialOverlay';
import CrystalDock from '../UI/CrystalDock';
import { playIsabellaGreeting, playIsabellaContextualCue } from '../../services/geminiService';
import { KAOS } from '../../services/kaosAudio';
import { ZoneData, ThreatLevel } from '../../types';
import { useExperience } from '../../contexts/ExperienceContext';

interface TamvWorldProps {
  apiKey: string;
  showTutorial: boolean;
  onTutorialComplete: () => void;
  userProfile: any;
}

const generateZones = (): ZoneData[] => {
  const categories = {
    SOCIAL: '#22d3ee',
    ECONOMY: '#facc15',
    KNOWLEDGE: '#4ade80',
    CREATIVE: '#a855f7',
    SYSTEM: '#e2e8f0',
  };

  const items = [
    { id: 'profile', name: 'User Profile', cat: 'SYSTEM', desc: 'Identity & Reputation' },
    { id: 'wallet', name: 'NubiWallet', cat: 'ECONOMY', desc: 'Your crypto assets' },
    { id: 'wishlist', name: 'Wishlist', cat: 'ECONOMY', desc: 'Saved desires' },
    { id: 'channels', name: 'Channels', cat: 'SOCIAL', desc: 'Public communication streams' },
    { id: 'market', name: 'Marketplace', cat: 'ECONOMY', desc: 'Trade assets & services' },
    { id: 'photos', name: 'Photo Gallery', cat: 'SOCIAL', desc: 'Visual memories' },
    { id: 'university', name: 'TAMV University', cat: 'KNOWLEDGE', desc: 'Learn & Evolve' },
    { id: 'dreamspace', name: 'DreamSpaces', cat: 'CREATIVE', desc: 'Create your reality' },
  ];

  const zones: ZoneData[] = [];
  const phi = (1 + Math.sqrt(5)) / 2;

  items.forEach((item, i) => {
    const distance = 8 + (i * 2.0); 
    const angle = 2 * Math.PI * i / (phi * phi) + (i * 0.1); 
    const x = distance * Math.cos(angle);
    const z = distance * Math.sin(angle);
    const y = Math.sin(i * 0.5) * 3;

    zones.push({
      id: item.id,
      name: item.name,
      category: item.cat as any,
      description: item.desc,
      position: [x, y, z],
      color: categories[item.cat as keyof typeof categories],
      scale: 1 + (i * 0.1)
    });
  });

  return zones;
};

// --- AUDIO LISTENER UPDATE COMPONENT ---
const KaosAudioListener = () => {
    const { camera } = useThree();
    useFrame(() => {
        KAOS.updateListener(camera.position, camera.quaternion);
    });
    return null;
}

// --- REACTIVE SKYBOX ---
const ImmersiveSkybox = ({ activeZone }: { activeZone: string | null }) => {
  const { state } = useExperience();
  
  let textureUrl = 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2560'; // Default

  // Theme-based Skybox switching
  if (state.threatLevel === ThreatLevel.CRITICAL) {
      textureUrl = 'https://images.unsplash.com/photo-1590907047706-ee9c08cf3189?q=80&w=2560'; // Force Void Red
  } else if (state.theme === 'ritual') {
      textureUrl = 'https://images.unsplash.com/photo-1590907047706-ee9c08cf3189?q=80&w=2560'; 
  } else if (state.theme === 'golden_hour') {
      textureUrl = 'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?q=80&w=2560';
  } else if (state.theme === 'nebula') {
      textureUrl = 'https://images.unsplash.com/photo-1534972195531-d756b9bfa9f2?q=80&w=2560';
  }

  const texture = useLoader(THREE.TextureLoader, textureUrl);
  
  return (
    <group>
        <mesh>
            <sphereGeometry args={[100, 64, 64]} />
            <meshBasicMaterial 
                map={texture} 
                side={THREE.BackSide} 
                transparent 
                opacity={state.threatLevel === ThreatLevel.CRITICAL ? 0.05 : (state.mode === 'calm' ? 0.2 : 0.4)} 
                blending={THREE.AdditiveBlending}
                depthWrite={false}
                color={state.threatLevel === ThreatLevel.CRITICAL ? '#ff0000' : '#ffffff'}
            />
        </mesh>
        <Environment preset={activeZone === 'dreamspace' ? "sunset" : "city"} blur={0.6} />
    </group>
  );
};

// --- REACTIVE MATRIX FLOOR ---
const MatrixFloor = () => {
  const matRef = useRef<THREE.ShaderMaterial>(null!);
  const { state } = useExperience();

  const palette = useMemo(() => {
    if (state.threatLevel === ThreatLevel.CRITICAL) {
         return { a: new THREE.Color('#ff0000'), b: new THREE.Color('#330000'), base: new THREE.Color('#000000') };
    }
    
    switch (state.theme) {
        case 'golden_hour':
            return { a: new THREE.Color('#ffaa00'), b: new THREE.Color('#ff4400'), base: new THREE.Color('#1a0500') };
        case 'ritual':
             return { a: new THREE.Color('#ff0055'), b: new THREE.Color('#550022'), base: new THREE.Color('#1a0005') };
        case 'dark':
             return { a: new THREE.Color('#444444'), b: new THREE.Color('#222222'), base: new THREE.Color('#000000') };
        case 'cyber_aqua':
        default:
            return { a: new THREE.Color('#00f5ff'), b: new THREE.Color('#c0c0c0'), base: new THREE.Color('#020511') };
    }
  }, [state.theme, state.threatLevel]);

  useFrame((clock) => {
    if (!matRef.current) return;
    matRef.current.uniforms.uTime.value = clock.clock.elapsedTime;
    matRef.current.uniforms.uColorA.value.lerp(palette.a, 0.05);
    matRef.current.uniforms.uColorB.value.lerp(palette.b, 0.05);
    matRef.current.uniforms.uBase.value.lerp(palette.base, 0.05);
  });

  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -6, 0]} receiveShadow>
      <planeGeometry args={[120, 120, 64, 64]} />
      <shaderMaterial
        ref={matRef}
        transparent={true}
        side={THREE.DoubleSide}
        uniforms={{
          uTime: { value: 0 },
          uColorA: { value: palette.a }, 
          uColorB: { value: palette.b }, 
          uBase: { value: palette.base },   
        }}
        vertexShader={`
          varying vec2 vUv;
          uniform float uTime;
          void main() {
            vUv = uv;
            vec3 pos = position;
            float wave = sin((position.x + position.y) * 0.1 + uTime * 0.7) * 0.15;
            wave += cos(position.x * 0.2 - uTime * 0.5) * 0.1;
            pos.z += wave;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
          }
        `}
        fragmentShader={`
          uniform float uTime;
          uniform vec3 uColorA;
          uniform vec3 uColorB;
          uniform vec3 uBase;
          varying vec2 vUv;

          float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123); }
          float lineGrid(vec2 uv) {
            vec2 g = abs(fract(uv - 0.5) - 0.5) / fwidth(uv);
            return 1.0 - min(min(g.x, g.y), 1.0);
          }

          void main() {
            vec2 uv = vUv * 40.0;
            float t = uTime * 1.5;
            vec2 id = floor(uv);
            float rnd = hash(id);
            float trail = fract(t * 0.2 + rnd);
            float stripe = step(0.1, fract(uv.x)) * step(fract(uv.x), 0.9);
            float rain = smoothstep(0.0, 0.4, abs(uv.y - trail * 30.0));
            float col = stripe * rain;
            float grid = lineGrid(uv * 0.5);
            vec3 matrixGlow = mix(uColorB, uColorA, col);
            vec3 gridColor = mix(uBase, uColorB, grid * 0.5);
            vec3 finalColor = mix(gridColor, matrixGlow, col);
            finalColor += col * 0.8; 
            float dist = distance(vUv, vec2(0.5));
            float alpha = 1.0 - smoothstep(0.3, 0.48, dist);
            gl_FragColor = vec4(finalColor, alpha);
          }
        `}
      />
    </mesh>
  );
};

// --- CAMERA CONTROLLER ---
const CameraController = ({ targetPos, targetLookAt, controlsRef }: any) => {
  const { camera } = useThree();
  const vecPos = useRef(new THREE.Vector3());
  const vecLook = useRef(new THREE.Vector3());

  useFrame((state, delta) => {
    if (controlsRef.current) {
      vecPos.current.set(...targetPos);
      camera.position.lerp(vecPos.current, 1.5 * delta);
      
      vecLook.current.set(...targetLookAt);
      controlsRef.current.target.lerp(vecLook.current, 2.0 * delta);
      controlsRef.current.update();
    }
  });
  return null;
}

// --- MAIN COMPONENT ---
const TamvWorld: React.FC<TamvWorldProps> = ({ apiKey, showTutorial, onTutorialComplete, userProfile }) => {
  const [activeZone, setActiveZone] = useState<string | null>(null);
  const [camPos, setCamPos] = useState<[number, number, number]>([0, 10, 30]);
  const [camTarget, setCamTarget] = useState<[number, number, number]>([0, 0, 0]);
  const [isabellaReaction, setIsabellaReaction] = useState<number>(0);
  const controlsRef = useRef<any>(null);
  
  // Consume Global State
  const { state } = useExperience();

  const zones = useMemo(() => generateZones(), []);

  // REACTIVE: Sync Audio with Global AudioPreset
  useEffect(() => {
      KAOS.setPreset(state.audioPreset);
  }, [state.audioPreset]);

  // REACTIVE: Sync Audio Volume
  useEffect(() => {
      KAOS.setVolume(state.volume);
  }, [state.volume]);

  // REACTIVE: Sync Threat Level with Audio
  useEffect(() => {
      KAOS.setThreatLevel(state.threatLevel);
  }, [state.threatLevel]);

  useEffect(() => {
    const initAudio = async () => {
        await KAOS.init();
        KAOS.playSynthesizedDrone('hub_ambience', new THREE.Vector3(0,0,0));
    };
    initAudio();

    if (!showTutorial) {
        const timer = setTimeout(() => {
            playIsabellaGreeting();
        }, 1500);
        return () => clearTimeout(timer);
    }
  }, [showTutorial]);

  const handleNavigate = (id: string) => {
    if (id === 'hub') {
        handleBackToHub();
        return;
    }

    setActiveZone(id);
    const zone = zones.find(z => z.id === id);
    
    if (zone) {
      playIsabellaContextualCue(zone.name, zone.category);
      setIsabellaReaction(Date.now());
      setCamTarget([zone.position[0], zone.position[1], zone.position[2]]);
      setCamPos([zone.position[0] * 1.3, zone.position[1] + 2, zone.position[2] + 6]);
    } else if (id === 'photos' || id === 'videos') {
         setCamTarget([20, 5, 0]);
         setCamPos([20, 5, 15]);
         playIsabellaContextualCue('Media Gallery', 'SOCIAL');
         setIsabellaReaction(Date.now());
    }
  };

  const handleBackToHub = () => {
    setActiveZone(null);
    setCamPos([0, 10, 30]);
    setCamTarget([0, 0, 0]);
  };

  const isCritical = state.threatLevel === ThreatLevel.CRITICAL;
  const isElevated = state.threatLevel === ThreatLevel.ELEVATED;

  return (
    <div className="w-full h-screen bg-black relative">
      <Canvas 
        shadows 
        dpr={[1, 2]} 
        camera={{ position: [0, 10, 30], fov: 40 }}
        gl={{ 
            antialias: true, 
            toneMapping: THREE.ACESFilmicToneMapping, 
            toneMappingExposure: isCritical ? 0.3 : 1.2, // Darken on critical
            powerPreference: "high-performance"
        }}
      >
        <fog attach="fog" args={[
            isCritical ? '#050000' : (state.theme === 'golden_hour' ? '#1a0500' : '#050505'), 
            15, 
            90
        ]} />
        <KaosAudioListener />
        
        <CameraController 
          targetPos={camPos} 
          targetLookAt={camTarget} 
          controlsRef={controlsRef} 
        />

        <ImmersiveSkybox activeZone={activeZone} />
        <ambientLight intensity={isCritical ? 0.05 : (state.mode === 'calm' ? 0.2 : 0.4)} />
        <pointLight position={[0, 10, 0]} intensity={isCritical ? 0.5 : 2} color={isCritical ? "#ff0000" : "#ffffff"} distance={50} />
        
        <Stars 
            radius={200} 
            depth={50} 
            count={isCritical ? 100 : (state.mode === 'focus' ? 2000 : 5000)} 
            factor={4} 
            saturation={0} 
            fade 
            speed={state.mode === 'ecstasy' ? 3 : 1} 
        />
        <Cloud opacity={0.3} speed={0.4} width={20} depth={5} segments={20} position={[0, -5, -20]} color={isCritical ? "#220000" : "#1a1a2e"} />

        <IsabellaOracle 
            apiKey={apiKey} 
            reactionTrigger={isabellaReaction} 
            onNavigate={handleNavigate}
        />
        
        {zones.map(zone => (
          <IridescentNode key={zone.id} data={zone} onInteract={handleNavigate} />
        ))}
        
        {(activeZone === 'photos' || activeZone === 'videos') && (
            <group position={[20, 0, 0]}>
                <MediaCarousel items={[
                    { id: '1', type: 'IMAGE', url: 'https://picsum.photos/400/300?random=1', title: 'Cyber City' },
                    { id: '2', type: 'IMAGE', url: 'https://picsum.photos/400/300?random=2', title: 'Neon Night' },
                    { id: '3', type: 'IMAGE', url: 'https://picsum.photos/400/300?random=3', title: 'Digital Soul' },
                ]} />
            </group>
        )}

        <MatrixFloor />

        {/* --- REACTIVE POST PROCESSING --- */}
        <EffectComposer disableNormalPass>
            <Bloom 
                luminanceThreshold={state.mode === 'ecstasy' ? 0.3 : 0.7} 
                mipmapBlur 
                intensity={isCritical ? 3.0 : (state.intensity * 2.5)} 
                radius={0.6} 
                levels={9}
            />
            {/* Critical threat causes massive distortion/glitch vibe via Chromatic Aberration & Noise */}
            <ChromaticAberration offset={new THREE.Vector2(isCritical ? 0.02 : (state.mode === 'ecstasy' ? 0.005 : 0.002), 0.002)} />
            <Noise opacity={isCritical ? 0.4 : (state.mode === 'calm' ? 0.02 : 0.05)} />
            <Vignette eskil={false} offset={0.1} darkness={isCritical ? 0.9 : 0.6} />
        </EffectComposer>

        <OrbitControls 
          ref={controlsRef}
          enablePan={false}
          maxPolarAngle={Math.PI / 2 - 0.05}
          minDistance={5}
          maxDistance={80}
          autoRotate={!activeZone && !showTutorial} 
          autoRotateSpeed={state.mode === 'ecstasy' ? 1.0 : 0.3}
          enableDamping
          dampingFactor={0.05}
        />
      </Canvas>

      {/* --- UI LAYER --- */}
      <CrystalDock onNavigate={handleNavigate} activeZone={activeZone} />
      {showTutorial && <TutorialOverlay onComplete={onTutorialComplete} />}
      {activeZone === 'market' && <MarketInterface onClose={handleBackToHub} />}

      <div className="absolute top-6 left-6 pointer-events-none select-none z-30">
        <h1 className="text-4xl font-bold text-white tracking-[0.2em] font-orbitron drop-shadow-[0_0_15px_rgba(34,211,238,0.8)]">
          TAMV <span className="text-cyan-400 text-sm align-top">OS v4.0</span>
        </h1>
        <div className="flex gap-2 mt-2">
            <div className="h-1 w-12 rounded-full animate-pulse transition-colors" style={{ backgroundColor: isCritical ? '#ff0000' : (state.mode === 'ecstasy' ? '#ff0055' : '#06b6d4') }}></div>
            <div className="text-xs text-gray-400 font-mono pl-2">USER: {userProfile.username}</div>
            <div className="text-xs text-gray-500 font-mono border-l border-gray-700 pl-2 ml-2 uppercase">MODE: {state.mode}</div>
            {isCritical && <div className="text-xs text-red-500 font-mono font-bold animate-pulse pl-2 ml-2">⚠️ SECURITY ALERT</div>}
        </div>
      </div>
    </div>
  );
};

export default TamvWorld;