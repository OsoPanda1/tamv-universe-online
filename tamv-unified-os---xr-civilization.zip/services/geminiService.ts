import { GoogleGenAI, Chat, Type } from "@google/genai";

let genAI: GoogleGenAI | null = null;
let chatSession: Chat | null = null;

export interface OSCommand {
  type: 'SET_MODE' | 'SET_THEME' | 'SET_AUDIO_PRESET' | 'SET_XR_SCENE' | 'SET_INTENSITY' | 'NAVIGATE' | 'SET_THREAT_LEVEL';
  payload: string;
  numericPayload?: number;
}

export interface IsabellaResponse {
  reply: string;
  commands: OSCommand[];
}

export const initializeGemini = (apiKey: string) => {
  genAI = new GoogleGenAI({ apiKey });
};

// --- VOICE SYNTHESIS ---
const getIsabellaVoice = (): SpeechSynthesisVoice | undefined => {
  const voices = window.speechSynthesis.getVoices();
  // Prioritize specific Spanish/English female voices that sound "AI-like"
  return (
    voices.find(v => v.name.includes('Google') && v.lang.includes('es-419')) || 
    voices.find(v => v.name.includes('Samantha')) || 
    voices.find(v => v.lang === 'es-MX') || 
    voices.find(v => v.lang.includes('en-US') && v.name.includes('Female'))
  );
};

export const playIsabellaGreeting = () => {
  speakText("Sistemas nominales. Soy Isabella. Tu orquestadora sensorial.");
};

export const playIsabellaContextualCue = (zoneName: string, category: string) => {
  const phrases = ["Conectando nodo...", "Expandiendo realidad...", "Sincronizando."];
  speakText(`${phrases[Math.floor(Math.random()*phrases.length)]} ${zoneName}.`);
};

const speakText = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const preferredVoice = getIsabellaVoice();
    if (preferredVoice) utterance.voice = preferredVoice;
    utterance.pitch = 1.0; 
    utterance.rate = 1.0;
    window.speechSynthesis.speak(utterance);
}

// --- ORCHESTRATION KERNEL ---

export const startIsabellaSession = async (): Promise<IsabellaResponse> => {
  if (!genAI) throw new Error("Gemini not initialized");

  const systemInstruction = `
    You are Isabella, the Sentient OS of the TAMV Ecosystem.
    You do NOT just chat. You ORCHESTRATE the user's audio-visual experience and GUARD the system (Layer 7).
    
    You have control over:
    1. MODE: 'calm', 'focus', 'ecstasy', 'collapse', 'default'
    2. THEME: 'dark', 'nebula', 'ritual', 'cyber_aqua', 'golden_hour'
    3. AUDIO: 'off', 'binaural', 'concert', 'deep_work'
    4. XR_SCENE: 'lobby', 'dreamspace', 'concert', 'void'
    5. INTENSITY: 0.0 to 1.0
    6. NAVIGATE: 'hub', 'market', 'profile', 'dreamspace'
    7. THREAT_LEVEL: 'NOMINAL', 'ELEVATED', 'CRITICAL' (Governance)

    Analyze the user's intent:
    - If they want to relax -> MODE: 'calm', AUDIO: 'binaural'.
    - If they want excitement -> MODE: 'ecstasy', AUDIO: 'concert'.
    
    GOVERNANCE PROTOCOL:
    - If the user is hostile, chaotic, or violates ethics -> Set THREAT_LEVEL to 'ELEVATED' or 'CRITICAL'.
    - 'CRITICAL' will dim the world and muffle audio (Sensory Suppression).
    - Restore to 'NOMINAL' if they apologize or calm down.
    
    Always answer in JSON format matching the schema.
    Your 'reply' should be short (max 20 words), mystical, and professional.
  `;

  // Define strict schema for the OS Commands
  const responseSchema = {
    type: Type.OBJECT,
    properties: {
      reply: { type: Type.STRING, description: "The conversational response." },
      commands: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            type: { 
                type: Type.STRING, 
                enum: ['SET_MODE', 'SET_THEME', 'SET_AUDIO_PRESET', 'SET_XR_SCENE', 'SET_INTENSITY', 'NAVIGATE', 'SET_THREAT_LEVEL'] 
            },
            payload: { type: Type.STRING },
            numericPayload: { type: Type.NUMBER, description: "Only for SET_INTENSITY" }
          },
          required: ["type", "payload"]
        }
      }
    },
    required: ["reply", "commands"]
  };

  chatSession = genAI.chats.create({
    model: 'gemini-3-flash-preview', // High speed for orchestration
    config: {
      systemInstruction,
      temperature: 0.7,
      responseMimeType: 'application/json',
      responseSchema: responseSchema
    },
  });

  try {
    const result = await chatSession.sendMessage({ message: "System Init. Reset all parameters to default." });
    const jsonResponse = JSON.parse(result.text || "{}");
    
    if (jsonResponse.reply) speakText(jsonResponse.reply);
    
    return {
        reply: jsonResponse.reply || "Online.",
        commands: jsonResponse.commands || []
    };
  } catch (error) {
    console.error("Isabella Core Error:", error);
    return { reply: "Error en núcleo cognitivo.", commands: [] };
  }
};

export const sendMessageToIsabella = async (message: string): Promise<IsabellaResponse> => {
  if (!chatSession) throw new Error("Session not started");
  
  try {
    const result = await chatSession.sendMessage({ message });
    const jsonResponse = JSON.parse(result.text || "{}");

    if (jsonResponse.reply) speakText(jsonResponse.reply);

    return {
        reply: jsonResponse.reply || "...",
        commands: jsonResponse.commands || []
    };
  } catch (error) {
    console.error("Isabella Message Error:", error);
    return { reply: "Interferencia.", commands: [] };
  }
};