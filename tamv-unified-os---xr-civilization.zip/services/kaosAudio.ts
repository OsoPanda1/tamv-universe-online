import * as THREE from 'three';
import { AudioPreset, ThreatLevel } from '../types';

// KAOS AUDIO 3D - Core Engine
class KaosAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private filterNode: BiquadFilterNode | null = null;
  private sources: Map<string, { panner: PannerNode, gain: GainNode, source?: AudioBufferSourceNode }> = new Map();
  private currentPreset: AudioPreset = 'off';
  private currentThreat: ThreatLevel = ThreatLevel.NOMINAL;

  constructor() {}

  public async init() {
    if (this.ctx) return;
    
    const AudioContextClass = (window.AudioContext || (window as any).webkitAudioContext);
    this.ctx = new AudioContextClass();
    
    if (this.ctx.state === 'suspended') {
        await this.ctx.resume();
    }

    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 0.5;

    this.filterNode = this.ctx.createBiquadFilter();
    this.filterNode.type = 'lowpass';
    this.filterNode.frequency.value = 20000;
    this.filterNode.Q.value = 0.5;

    this.filterNode.connect(this.masterGain);
    this.masterGain.connect(this.ctx.destination);
  }

  public setVolume(val: number) {
      if (this.masterGain) {
          const t = this.ctx?.currentTime || 0;
          this.masterGain.gain.linearRampToValueAtTime(val, t + 0.5);
      }
  }

  public setThreatLevel(level: ThreatLevel) {
      if (!this.ctx || !this.filterNode) return;
      this.currentThreat = level;
      const t = this.ctx.currentTime;

      if (level === ThreatLevel.CRITICAL) {
          // Sensory Suppression: Muffle audio drastically
          console.log('[KAOS] SECURITY PROTOCOL: CRITICAL');
          this.filterNode.frequency.exponentialRampToValueAtTime(500, t + 0.5);
          this.filterNode.Q.value = 2.0; // Resonant distortion
      } else if (level === ThreatLevel.ELEVATED) {
          this.filterNode.frequency.exponentialRampToValueAtTime(4000, t + 1.0);
      } else {
          // Restore based on preset
          this.setPreset(this.currentPreset);
      }
  }

  public setPreset(preset: AudioPreset) {
      if (!this.ctx || !this.filterNode) return;
      // If critical threat, ignore presets until threat cleared
      if (this.currentThreat === ThreatLevel.CRITICAL) return;

      const t = this.ctx.currentTime;
      this.currentPreset = preset;
      
      console.log(`[KAOS] Applying Preset: ${preset}`);

      switch (preset) {
          case 'binaural':
              // Deep, focused, muffled highs
              this.filterNode.frequency.exponentialRampToValueAtTime(600, t + 2.0);
              this.filterNode.Q.value = 0.8;
              this.masterGain!.gain.linearRampToValueAtTime(0.4, t + 2.0);
              break;
          case 'concert':
              // Wide open, loud
              this.filterNode.frequency.exponentialRampToValueAtTime(22000, t + 1.0);
              this.filterNode.Q.value = 0.1;
              this.masterGain!.gain.linearRampToValueAtTime(0.8, t + 1.0);
              break;
          case 'deep_work':
              // Specific focus frequency
              this.filterNode.frequency.exponentialRampToValueAtTime(1200, t + 1.0);
              this.masterGain!.gain.linearRampToValueAtTime(0.6, t + 1.0);
              break;
          case 'off':
          default:
              this.filterNode.frequency.exponentialRampToValueAtTime(20000, t + 1.0);
              this.masterGain!.gain.linearRampToValueAtTime(0.5, t + 1.0);
              break;
      }
  }

  public updateListener(position: THREE.Vector3, orientation: THREE.Quaternion) {
    if (!this.ctx || !this.ctx.listener) return;
    const t = this.ctx.currentTime;
    const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(orientation);
    const up = new THREE.Vector3(0, 1, 0).applyQuaternion(orientation);

    if (this.ctx.listener.positionX) {
        this.ctx.listener.positionX.setTargetAtTime(position.x, t, 0.1);
        this.ctx.listener.positionY.setTargetAtTime(position.y, t, 0.1);
        this.ctx.listener.positionZ.setTargetAtTime(position.z, t, 0.1);
        this.ctx.listener.forwardX.setTargetAtTime(forward.x, t, 0.1);
        this.ctx.listener.forwardZ.setTargetAtTime(forward.z, t, 0.1);
        this.ctx.listener.upX.setTargetAtTime(up.x, t, 0.1);
    }
  }

  public playSynthesizedDrone(id: string, position: THREE.Vector3) {
      if (!this.ctx || !this.filterNode) return;
      
      const panner = this.ctx.createPanner();
      panner.panningModel = 'HRTF';
      panner.setPosition(position.x, position.y, position.z);
      
      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = 55; // A1
      
      const gain = this.ctx.createGain();
      gain.gain.value = 0.15;

      osc.connect(gain);
      gain.connect(panner);
      panner.connect(this.filterNode);
      
      osc.start();
      this.sources.set(id, { panner, gain, source: osc as any });
  }
}

export const KAOS = new KaosAudioEngine();