export enum AppState {
  LOADING = 'LOADING',
  API_KEY_SELECT = 'API_KEY_SELECT',
  REGISTRATION = 'REGISTRATION',
  TUTORIAL = 'TUTORIAL',
  HUB = 'HUB',
  DREAM_SPACE = 'DREAM_SPACE',
  MARKET = 'MARKET',
  GOVERNANCE = 'GOVERNANCE'
}

export enum InteractionType {
  NONE = 'NONE',
  ISABELLA_CHAT = 'ISABELLA_CHAT',
  TOTEM_VIEW = 'TOTEM_VIEW',
  PANEL_INFO = 'PANEL_INFO'
}

export type ExperienceMode = 'calm' | 'focus' | 'ecstasy' | 'collapse' | 'default';
export type ExperienceTheme = 'dark' | 'nebula' | 'ritual' | 'cyber_aqua' | 'golden_hour';
export type AudioPreset = 'off' | 'binaural' | 'concert' | 'deep_work';
export type XRScene = 'lobby' | 'dreamspace' | 'concert' | 'void';

// LAYER 7: GOVERNANCE & PROTECTION
export enum ThreatLevel {
  NOMINAL = 'NOMINAL',
  ELEVATED = 'ELEVATED',
  CRITICAL = 'CRITICAL'
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface ZoneData {
  id: string;
  name: string;
  category: 'SOCIAL' | 'ECONOMY' | 'KNOWLEDGE' | 'CREATIVE' | 'SYSTEM';
  description: string;
  position: [number, number, number];
  color: string;
  scale?: number;
}

export interface MarketItem {
  id: string;
  name: string;
  type: 'ASSET' | 'SERVICE';
  price: number;
  currency: 'MSR' | 'TAMV';
  rarity: 'COMMON' | 'RARE' | 'LEGENDARY';
  description: string;
}

export interface UserProfile {
  id: string;
  username: string;
  avatarId?: string;
  reputation: number;
  wallet: {
    msr: number;
    tamv: number;
  }
}

export interface MediaItem {
  id: string;
  type: 'IMAGE' | 'VIDEO';
  url: string;
  title: string;
}